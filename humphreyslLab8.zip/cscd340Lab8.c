#include "./pipes/pipes.h"
#include "./utils/myUtils.h"
#include "./process/process.h"
#include "./tokenize/makeArgs.h"
#include "./linkedlist/linkedList.h"
#include "./path/path.h"
#include "./path/pathUtils.h"


int main()
{
	char * p = getenv("PATH");
	replacePath(p);
	printList(PATH, printType);

/* Stu's Code */
  int argc, pipeCount;
  char **argv = NULL, s[MAX];
  int preCount = 0, postCount = 0;
  char ** prePipe = NULL, ** postPipe = NULL;
//Laura's two lines
  char ** midPipe = NULL;
  int midCount = 0;

  printf("command?: ");
  fgets(s, MAX, stdin);
  strip(s);

  while(strcmp(s, "exit") != 0)
  { /* End Stu's Code */

 
	//Laura's Code
	if(strstr(s, "PATH") != NULL)
	{
		parsePath(s);
	}
	else
	{
		pipeCount = containsPipe(s);
		if(pipeCount > 0)
		{
			if(pipeCount == 1)
			{	
				prePipe = parsePrePipe(s, &preCount);
				postPipe = parsePostPipe(s, &postCount);
				pipeIt(prePipe, postPipe);
				clean(preCount, prePipe);
				clean(postCount, postPipe);
			}else{
				prePipe = parsePrePipe(s, &preCount);
				midPipe = parseMidPipe(s, &midCount);
				postPipe = parsePostPipe(s, &postCount);
				pipeItTwice(prePipe, midPipe, postPipe);
				clean(preCount, prePipe);
				clean(midCount, midPipe);
				clean(postCount, postPipe);

			}
		}// end if pipeCount	  

		else
		{
			argc = makeargs(s, &argv);
		  	if(argc != -1)
				//printargs(argc, argv);
		  		forkIt(argv);
		  
		  	clean(argc, argv);
		  	argv = NULL;
		}//End Laura's Code
	}
/* Stu's Code */
	printf("command?: ");
	fgets(s, MAX, stdin);
      	strip(s);

  }// end while
/* End Stu's Code */  

	cleanPath();
  return 0;

}// end main

