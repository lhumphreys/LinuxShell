#ifndef HISTORY_H
#define HISTORY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct history
{
	char * line;
};
typedef struct history History;


#endif
