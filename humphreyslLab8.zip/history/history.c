#include "history.h"

void printType(History * passedIn)
{
	printf("$s", (*passedIn).line);
}

void * buildType(FILE * fin){}
void * builtType_Prompt(FILE * fin){}

int compare(const History * h1, const History * h2)
{
	int cmp = 0;
	cmp = strcmp((*h1).line, (*h2).line);
}

void cleanType(History * passedIn)
{
	free((*passedIn).line);
	(*passedIn).line = NULL;
	free(passedIn);
	passedIn = NULL;
}
