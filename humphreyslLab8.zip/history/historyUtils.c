#include "historyUtils.h"

void cleanHistory()
{
	
}
