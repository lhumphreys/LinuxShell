#ifndef PATH_H
#define PATH_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct path
{
	char * location;
};
typedef struct path Path;

#endif
